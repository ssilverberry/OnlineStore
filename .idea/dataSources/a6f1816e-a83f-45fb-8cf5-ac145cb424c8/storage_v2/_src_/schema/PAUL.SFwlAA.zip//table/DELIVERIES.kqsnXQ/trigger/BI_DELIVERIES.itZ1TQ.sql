create trigger BI_DELIVERIES
  before insert
  on DELIVERIES
  for each row
  begin
    if :NEW."DELIVERY_ID" is null then
      select "DELIVERY_SEQ".nextval into :NEW."DELIVERY_ID" from dual;
    end if;
  end;
/

