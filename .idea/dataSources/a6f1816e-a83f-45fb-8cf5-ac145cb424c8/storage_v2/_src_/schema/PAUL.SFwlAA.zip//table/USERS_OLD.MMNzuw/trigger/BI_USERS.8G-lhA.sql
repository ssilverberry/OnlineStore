create trigger BI_USERS
  before insert
  on USERS_OLD
  for each row
  begin
    if :NEW."USER_ID" is null then
      select "USERS_SEQ".nextval into :NEW."USER_ID" from dual;
    end if;
  end;
/

