create trigger TR_AUTO_INC
  before insert
  on USERS_OLD
  for each row
  begin 
    select auto_inc_user_id.nextval
      into :new.USER_ID
      from dual;
  end;
/

