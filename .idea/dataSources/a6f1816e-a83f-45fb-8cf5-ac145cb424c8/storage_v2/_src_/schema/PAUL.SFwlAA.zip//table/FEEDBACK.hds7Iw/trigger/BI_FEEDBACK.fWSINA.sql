create trigger BI_FEEDBACK
  before insert
  on FEEDBACK
  for each row
  begin
    if :NEW."FEEDBACK_ID" is null then
      select "FEEDBACK_SEQ".nextval into :NEW."FEEDBACK_ID" from dual;
    end if;
  end;
/

