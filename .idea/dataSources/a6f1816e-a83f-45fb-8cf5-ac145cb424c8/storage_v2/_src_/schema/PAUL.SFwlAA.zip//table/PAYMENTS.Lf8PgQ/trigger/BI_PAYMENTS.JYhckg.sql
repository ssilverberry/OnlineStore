create trigger BI_PAYMENTS
  before insert
  on PAYMENTS
  for each row
  begin
    if :NEW."PAYMENT_ID" is null then
      select "PAYMENT_SEQ".nextval into :NEW."PAYMENT_ID" from dual;
    end if;
  end;
/

