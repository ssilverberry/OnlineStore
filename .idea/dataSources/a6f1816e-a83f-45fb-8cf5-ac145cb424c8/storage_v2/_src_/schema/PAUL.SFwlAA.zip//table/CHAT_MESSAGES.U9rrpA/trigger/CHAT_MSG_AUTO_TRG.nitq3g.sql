create trigger CHAT_MSG_AUTO_TRG
  before insert
  on CHAT_MESSAGES
  for each row
  BEGIN
    SELECT chat_msg_auto_inc.nextval
    INTO :new.MESSAGE_ID
    FROM dual;
  END;
/

