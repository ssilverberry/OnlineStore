create trigger CHAT_TRG_AUTO_INC
  before insert
  on CHATS
  for each row
  BEGIN
    SELECT chat_auto_inc.nextval
    INTO :new.CHAT_ID
    FROM dual;
  END;
/

