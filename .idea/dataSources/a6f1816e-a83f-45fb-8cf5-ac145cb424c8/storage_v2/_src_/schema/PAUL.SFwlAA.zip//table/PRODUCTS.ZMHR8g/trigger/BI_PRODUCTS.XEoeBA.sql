create trigger BI_PRODUCTS
  before insert
  on PRODUCTS
  for each row
  begin
    if :NEW."PRODUCT_ID" is null then
      select "PRODUCT_SEQ".nextval into :NEW."PRODUCT_ID" from dual;
    end if;
  end;
/

