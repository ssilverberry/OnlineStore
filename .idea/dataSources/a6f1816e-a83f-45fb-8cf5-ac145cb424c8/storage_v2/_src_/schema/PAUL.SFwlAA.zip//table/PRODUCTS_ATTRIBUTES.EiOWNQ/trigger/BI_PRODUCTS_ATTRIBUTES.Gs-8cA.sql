create trigger BI_PRODUCTS_ATTRIBUTES
  before insert
  on PRODUCTS_ATTRIBUTES
  for each row
  begin
    if :NEW."ATTRIBUTE_ID" is null then
      select "PRODUCT_ATTRIBUTES".nextval into :NEW."ATTRIBUTE_ID" from dual;
    end if;
  end;
/

