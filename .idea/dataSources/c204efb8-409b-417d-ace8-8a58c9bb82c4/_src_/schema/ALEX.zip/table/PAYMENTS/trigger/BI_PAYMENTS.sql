CREATE TRIGGER BI_PAYMENTS
BEFORE INSERT
  ON PAYMENTS
FOR EACH ROW
  begin
    if :NEW."PAYMENT_ID" is null then
      select "PAYMENT_SEQ".nextval into :NEW."PAYMENT_ID" from dual;
    end if;
  end;
/
