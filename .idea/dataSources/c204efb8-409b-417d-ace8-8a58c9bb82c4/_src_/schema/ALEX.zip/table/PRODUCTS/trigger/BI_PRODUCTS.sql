CREATE TRIGGER BI_PRODUCTS
BEFORE INSERT
  ON PRODUCTS
FOR EACH ROW
  begin
    if :NEW."PRODUCT_ID" is null then
      select "PRODUCTS_SEQ".nextval into :NEW."PRODUCT_ID" from dual;
    end if;
  end;
/
