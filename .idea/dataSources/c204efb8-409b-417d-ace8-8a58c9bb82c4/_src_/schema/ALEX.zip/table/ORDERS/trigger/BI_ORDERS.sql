CREATE TRIGGER BI_ORDERS
BEFORE INSERT
  ON ORDERS
FOR EACH ROW
  begin
    if :NEW."ORDER_ID" is null then
      select "ORDERS_SEQ".nextval into :NEW."ORDER_ID" from dual;
    end if;
  end;
/
