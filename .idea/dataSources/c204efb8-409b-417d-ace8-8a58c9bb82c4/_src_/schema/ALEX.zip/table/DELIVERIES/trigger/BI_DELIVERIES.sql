CREATE TRIGGER BI_DELIVERIES
BEFORE INSERT
  ON DELIVERIES
FOR EACH ROW
  begin
    if :NEW."DELIVERY_ID" is null then
      select "DELIVERY_SEQ".nextval into :NEW."DELIVERY_ID" from dual;
    end if;
  end;
/
