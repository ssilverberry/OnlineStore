CREATE TRIGGER BI_FEEDBACK
BEFORE INSERT
  ON FEEDBACK
FOR EACH ROW
  begin
    if :NEW."FEEDBACK_ID" is null then
      select "FEEDBACK_SEQ".nextval into :NEW."FEEDBACK_ID" from dual;
    end if;
  end;
/
