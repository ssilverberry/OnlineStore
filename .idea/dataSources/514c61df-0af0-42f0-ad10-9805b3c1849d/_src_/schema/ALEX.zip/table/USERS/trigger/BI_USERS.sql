CREATE TRIGGER BI_USERS
BEFORE INSERT
  ON USERS
FOR EACH ROW
  begin
    if :NEW."USER_ID" is null then
      select "USERS_SEQ".nextval into :NEW."USER_ID" from dual;
    end if;
  end;
/
